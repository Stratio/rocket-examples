

def dummy_func(x):
    return "Dummy code - {}".format(str(x))

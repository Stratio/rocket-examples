
def user_func(x):
    return f"Hello '{x}' I'm user2"


def user2_func(x):
    return f"Hello '{x}' I'm user2"

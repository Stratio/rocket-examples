
def user1_func(x):
    return f"Hello '{x}' I'm user1"

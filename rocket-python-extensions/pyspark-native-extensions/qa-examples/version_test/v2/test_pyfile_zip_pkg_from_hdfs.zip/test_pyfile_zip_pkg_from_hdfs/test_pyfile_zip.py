
def func_test_pyfile_zip(x):
    return f"Hello '{x}' from python zip pkg placed in Hdfs - V2"

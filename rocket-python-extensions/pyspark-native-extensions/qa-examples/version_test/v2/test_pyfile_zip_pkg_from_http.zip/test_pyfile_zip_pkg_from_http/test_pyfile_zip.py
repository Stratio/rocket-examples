
def func_test_pyfile_zip(x):
    return f"Hello '{x}' from python zip pkg placed in a Http server - V2"
